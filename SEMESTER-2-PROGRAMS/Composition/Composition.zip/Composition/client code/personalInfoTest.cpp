#include <iostream>
#include "personalInfo.h"

int main()
{

 personalInfo myInfo;
 myInfo.printpersonalInfo();

 return 0;
}
