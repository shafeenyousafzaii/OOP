#include<iostream>
#include"task2.h"
using namespace std;
int main()
{
    cout<<"Iam here"<<endl;
  cout<<"I can see that"<<endl;
  /*right click on my name in the live share icon tray and click follow 
  then you willl see my cursor"*/ 
  //I can see that without following you
  // maybe that is becasue i amthe admin got it
  //lets go
  //send me your file i will put it here 
  //we can work on it 
  //ther is also a chat bar 
  //and also audio call feature
  //really good extension
 }