#include"taskone.h"l
int main()
{
    Person one;
    one.SetInfo();
    one.DisplayZodiacInfo();
}