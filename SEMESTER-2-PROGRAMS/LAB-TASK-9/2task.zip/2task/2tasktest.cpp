#include<iostream>
#include<string>
#include<iomanip>
#include"2task.h"
using namespace std;
int main()
{
    skimmer s1(40,13000,"Swim and Fly",2);
    s1.SWIMANDFLY();
}